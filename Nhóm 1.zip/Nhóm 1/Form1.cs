﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dijkstra_Nhom1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void southMap_Paint(object creator, PaintEventArgs e)
        {
            Graphics graph = southMap.CreateGraphics();
            for (int i = 0; i < Locations.Count; i++)
            {
                SolidBrush brush = new SolidBrush(Color.SeaGreen);
                Brush pointName = new SolidBrush(Color.White);
                graph.FillEllipse(brush, Locations[i].getPoint().X - 3, Locations[i].getPoint().Y - 2, 18, 18);
                graph.DrawString(Locations[i].getPointName(), new Font("Arial", 8), pointName, Locations[i].getPoint().X, Locations[i].getPoint().Y);
            }
            DrawLine();
        }
        private void DrawLine(string a, string b)
        {
            Graphics graph = southMap.CreateGraphics();
            int x = g.GetIndex(a);
            int y = g.GetIndex(b);
            Pen p = new Pen(Color.Black, 2);
            Point point1 = new Point(g.listPoint[x].X, g.listPoint[x].Y);
            Point point2 = new Point(g.listPoint[y].X, g.listPoint[y].Y);
            graph.DrawLine(p, point1, point2);
            graph.DrawString($"{g.adj[x, y]}", new Font("Fira Code", 10), Brushes.Black, new Point((point1.X + point2.X) / 2 - 8, (point1.Y + point2.Y) / 2 + 8));
        }
        private void DrawPathLine(int i)
        {
            Graphics graph = southMap.CreateGraphics();
            Pen p = new Pen(Color.Red, 3);
            Point point1 = new Point(g.pathIndex[i].X, g.pathIndex[i].Y);
            Point point2 = new Point(g.pathIndex[i + 1].X, g.pathIndex[i + 1].Y);
            graph.DrawLine(p, point1, point2);
        }
        public List<Location> Locations = new List<Location>();
        SetUpGraph g = new SetUpGraph();
        private void Form1_Load(object creator, EventArgs e) 
        {
            Location laichau = new Location("Lai Châu", "A", 170,130);
            Location sonla = new Location("Sơn La", "B", 264, 227);
            Location laocai = new Location("Lào Cai", "C", 286, 85);
            Location yenbai = new Location("Yên Bái", "D", 325, 175);
            Location hagiang = new Location("Hà Giang", "E", 350, 80);
            Location caobang = new Location("Cao Bằng", "F", 445, 55);
            Location tuyenquang = new Location("Tuyên Quang", "G", 394, 148);
            Location langson = new Location("Lạng Sơn", "H", 510, 134);
            Location vinhphuc = new Location("Vĩnh Phúc", "I", 420, 205);
            Location thanhhoa = new Location("Thanh Hóa", "K", 366, 291);
            Locations.Add(laichau);
            Locations.Add(sonla);
            Locations.Add(laocai);
            Locations.Add(yenbai);
            Locations.Add(hagiang);
            Locations.Add(caobang);
            Locations.Add(tuyenquang);
            Locations.Add(langson);
            Locations.Add(vinhphuc);
            Locations.Add(thanhhoa);
            cbSource.Items.Add("Lai Châu");
            cbSource.Items.Add("Sơn La");
            cbSource.Items.Add("Lào Cai");
            cbSource.Items.Add("Yên Bái");
            cbSource.Items.Add("Hà Giang");
            cbSource.Items.Add("Cao Bằng");
            cbSource.Items.Add("Tuyên Quang");
            cbSource.Items.Add("Lạng Sơn");
            cbSource.Items.Add("Vĩnh Phúc");
            cbSource.Items.Add("Thanh Hóa");
            cbDestination.Items.Add("Lai Châu");
            cbDestination.Items.Add("Sơn La");
            cbDestination.Items.Add("Lào Cai");
            cbDestination.Items.Add("Yên Bái");
            cbDestination.Items.Add("Hà Giang");
            cbDestination.Items.Add("Cao Bằng");
            cbDestination.Items.Add("Tuyên Quang");
            cbDestination.Items.Add("Lạng Sơn");
            cbDestination.Items.Add("Vĩnh Phúc");
            cbDestination.Items.Add("Thanh Hóa");
            Graphics graph = southMap.CreateGraphics();
            for (int i = 0; i < Locations.Count; i++)
            {
                lvListProvinces.Items.Add(Locations[i].getPointName());
                lvListProvinces.Items[i].SubItems.Add(Locations[i].getName());
                g.listPoint.Add(Locations[i].getPoint());
                g.InsertVertex(Locations[i].getName());
            }
            g.InsertEdge("Lai Châu", "Sơn La", 190);
            g.InsertEdge("Lai Châu", "Lào Cai", 135);
            g.InsertEdge("Lào Cai", "Hà Giang", 200);
            g.InsertEdge("Lai Châu", "Yên Bái", 160);
            g.InsertEdge("Hà Giang", "Cao Bằng", 250);
            g.InsertEdge("Cao Bằng", "Lạng Sơn", 120);
            g.InsertEdge("Hà Giang", "Tuyên Quang", 145);
            g.InsertEdge("Tuyên Quang", "Lạng Sơn", 160);
            g.InsertEdge("Yên Bái", "Vĩnh Phúc", 130);
            g.InsertEdge("Vĩnh Phúc", "Lạng Sơn", 150);
            g.InsertEdge("Sơn La", "Vĩnh Phúc", 200);
            g.InsertEdge("Sơn La", "Thanh Hóa", 220);
            g.InsertEdge("Vĩnh Phúc", "Thanh Hóa", 180);
            g.InsertEdge("Thanh Hóa", "Lạng Sơn", 210);
            g.InsertEdge("Lào Cai", "Yên Bái", 100);
            g.InsertEdge("Sơn La", "Yên Bái", 100);
            g.InsertEdge("Yên Bái", "Tuyên Quang", 110);
        }
       
      

        private void DrawLine() 
        {
            DrawLine("Lai Châu", "Sơn La");
            DrawLine("Lai Châu", "Lào Cai");
            DrawLine("Lào Cai", "Hà Giang");
            DrawLine("Lai Châu", "Yên Bái");
            DrawLine("Hà Giang", "Cao Bằng");
            DrawLine("Cao Bằng", "Lạng Sơn");
            DrawLine("Hà Giang", "Tuyên Quang");
            DrawLine("Tuyên Quang", "Lạng Sơn");
            DrawLine("Yên Bái", "Vĩnh Phúc");
            DrawLine("Vĩnh Phúc", "Lạng Sơn");
            DrawLine("Sơn La", "Vĩnh Phúc");
            DrawLine("Sơn La", "Thanh Hóa");
            DrawLine("Vĩnh Phúc", "Thanh Hóa");
            DrawLine("Thanh Hóa", "Lạng Sơn");
            DrawLine("Lào Cai", "Yên Bái");
            DrawLine("Sơn La", "Yên Bái");
            DrawLine("Yên Bái", "Tuyên Quang");
        }
    
        private void cbSource_SelectedIndexChanged(object creator, EventArgs e)
        {
            if (cbSource.SelectedIndex != -1 && cbDestination.SelectedIndex != -1)
            {
                southMap.Controls.Clear();
                southMap.Refresh();
                DrawLine();
                g.pathIndex.Clear();
                tbKM.Clear();
                tbLiter.Clear();
                tbCost.Clear();
                tbPath.Clear();
                g.FindPaths(cbSource.SelectedItem.ToString(), cbDestination.SelectedIndex.ToString(),tbKM,tbLiter, tbCost, tbPath);
                for (int i = 0; i < g.pathIndex.Count - 1; i++)
                {
                    DrawPathLine(i);
                }
            }
            if (cbSource.SelectedIndex == cbDestination.SelectedIndex)
            {
                MessageBox.Show("Không phản hồi\n Điểm đi và đến không được trùng !", "Thông báo!");
            }
        }
        private void cbDestination_SelectedIndexChanged(object creator, EventArgs e)
        {
            if (cbSource.SelectedIndex != -1 && cbDestination.SelectedIndex != -1)
            {
                southMap.Controls.Clear();
                southMap.Refresh();
                DrawLine();
                g.pathIndex.Clear();
                tbKM.Clear();
                tbLiter.Clear();
                tbCost.Clear();
                tbPath.Clear();
                g.FindPaths(cbSource.SelectedItem.ToString(), cbDestination.SelectedIndex.ToString(),tbKM ,tbLiter, tbCost, tbPath);
                for (int i = 0; i < g.pathIndex.Count - 1; i++)
                {
                    DrawPathLine(i);
                }
            }
            if (cbSource.SelectedIndex == cbDestination.SelectedIndex)
            {
                MessageBox.Show("Không phản hồi\n Điểm đi và đến không được trùng !", "Thông báo!");
            }    
        }
    
  

        private void southMap_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label48_Click(object sender, EventArgs e)
        {

        }

        private void label55_Click(object sender, EventArgs e)
        {

        }

        private void lbInfo_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lvListProvinces_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label63_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void tbPath_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbKM_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lable12_Click(object sender, EventArgs e)
        {

        }

        private void tbLiter_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbCost_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void label47_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void label49_Click(object sender, EventArgs e)
        {

        }

        private void label50_Click(object sender, EventArgs e)
        {

        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void label51_Click(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void label34_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }

        private void label53_Click(object sender, EventArgs e)
        {

        }

        private void label56_Click(object sender, EventArgs e)
        {

        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label37_Click(object sender, EventArgs e)
        {

        }

        private void label54_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label38_Click(object sender, EventArgs e)
        {

        }

        private void label57_Click(object sender, EventArgs e)
        {

        }

        private void label39_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void label58_Click(object sender, EventArgs e)
        {

        }

        private void label59_Click(object sender, EventArgs e)
        {

        }

        private void label60_Click(object sender, EventArgs e)
        {

        }

        private void label61_Click(object sender, EventArgs e)
        {

        }

        private void label62_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void label46_Click(object sender, EventArgs e)
        {

        }

        private void label64_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
